import java.util.ArrayList;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Products {
String PC;
String PN;
String JC;
String WP;
double P;
String S;
String SL;


    Products(String ProductCode, String ProductName, String ProductCategory, String ProductWarranty, double ProductPrice, String ProductSupplier, String ProductStocklevel) {
        this.PN = ProductName;
        this.PC = ProductCode;
        this.WP = ProductWarranty;
        this.SL = ProductStocklevel;
        this.JC = ProductCategory;
        this.P = ProductPrice;
        this.S = ProductSupplier;
        
        
    }

    Products(String ProductName, String ProductCode, String ProductCategory, String ProductWarranty, String ProductSupplier, String ProductStocklevel, double ProductPrice) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}