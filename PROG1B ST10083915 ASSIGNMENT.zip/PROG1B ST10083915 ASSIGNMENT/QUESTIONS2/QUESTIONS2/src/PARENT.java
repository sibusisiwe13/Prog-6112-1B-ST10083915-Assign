/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class PARENT {
    private int age;
    private String firstname;
    private String lastname;
    private String address;
    
    public PARENT(int age, String firstname, String lastname, String address) {
        this.age = age;
        this.firstname = firstname;
        this.address = address;
        this.lastname = lastname;
        
    }
    public String toString() {
        return "The Parent's name is "+ this.firstname + " and surname is " + this.lastname+" age is " + age + ", the parent place of recidence is in " + this.address;
    }
    public int getAGE(){
        return age;
    }
    public String getFIRSTNAME() {
       return firstname;
   }
    public String getLASTNAME() {
        return lastname;
    }
    public String getADDRESS() {
        return address;
    }
    public void hasWork(){
        System.out.println("The parent works at the munciplicity as a civil engineer");
    }
    
}

class MOTHER extends PARENT {
 boolean retired;
    public MOTHER(int age, String firstname, String lastname, String address) {
        super(age, firstname, lastname, address);
        if(age>= 45){
            retired = true;
            
        }else{
            retired = false;
            
           
            }
         
            
        }
     public boolean getRetired(){
                return retired;
    
        
    }
 
    
    
}

