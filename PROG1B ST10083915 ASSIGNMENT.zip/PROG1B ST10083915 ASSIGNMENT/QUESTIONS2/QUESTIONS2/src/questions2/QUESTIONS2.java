/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questions2;

import java.util.ArrayList;
import static javafx.scene.AccessibleAttribute.PARENT;
import static javafx.scene.AccessibleRole.PARENT;

/**
 *
 * @author user
 */
public class QUESTIONS2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<PARENT> ParentList = new ArrayList<PARENT>();
        PARENT parent1 = new PARENT(45, "JOHN", "JAMESON", "45 RADER ROAD");
        ParentList.add(parent1);
        PARENT parent2 = new PARENT(35, "SINDY", "MICHAELS", "88 OXFORD RD");
        ParentList.add(parent2);
        PARENT parent3 = new PARENT(29, "KATEY", "ROBINSON", "09 BEACHWAY");
        ParentList.add(parent3);
        PARENT parent4 = new PARENT(55, "CHARLIE", "VAN VYK", "66 KENNTH KUWANDA RD");
        ParentList.add(parent4);
        PARENT parent5 = new PARENT(32, "WENDY", "WILLIAMSON", "77 COTTONFIELD");
        ParentList.add(parent5);
       
        MOTHER mother = new MOTHER(45, "June", "Adonis");
        System.out.println(mother.getClass());
        System.out.println(mother.getAge());
        
       
        
        
        for (int i = 0; i<ParentList.size(); i++){
            System.out.println(ParentList.get(i));
        }
        
        
        
        parent1.hasWork();
        System.out.println(parent1.getFIRSTNAME());
        System.out.println(parent1.getAGE());
        
        System.out.println(parent1);
        // TODO code application logic here
    }
    
}
